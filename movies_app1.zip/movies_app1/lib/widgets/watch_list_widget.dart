import 'package:flutter/material.dart';
import 'package:movies_app/widgets/watch_list_card.dart';

class WatchListWidget extends StatelessWidget {
  final List watchList;
  final String? genre;
  const WatchListWidget({Key? key, required this.watchList, this.genre})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: watchList.length,
      itemBuilder: (context, index) {
        return WatchListCard(
          movie: watchList[index],
          genre: genre,
        );
      },
    );
  }
}
