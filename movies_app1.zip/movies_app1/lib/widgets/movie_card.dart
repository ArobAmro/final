import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:movies_app/config/size_config.dart';
import 'package:movies_app/models/gener.dart';
import 'package:movies_app/models/movie_wach_list.dart';
import 'package:movies_app/screens/movie_details.dart';
import 'package:movies_app/services/database_handler.dart';
import 'package:movies_app/services/get_movie_details.dart';
import '../models/movie.dart';

class MovieCard extends StatefulWidget {
  final Movie movie;
  MovieCard({Key? key, this.title, required this.movie}) : super(key: key);
  final String? title;
  @override
  _MovieCardState createState() => _MovieCardState();
}

class _MovieCardState extends State<MovieCard> {
  late DatabaseHelper dbHelper;

  @override
  void initState() {
    super.initState();
    dbHelper = DatabaseHelper();
    dbHelper.initDB().whenComplete(() async {
      setState(() {});
    });
  }

  Future<int?> addMoviesToWatchList(MoviesWatchList moviesWatchList) async {
    return await dbHelper.insertToWatchList(moviesWatchList);
  }

  bool hasInternet = true;
  final snackBar = const SnackBar(
      backgroundColor: Color(0xffEA2828),
      content: Text(
        'No Internet Connection.',
        style: TextStyle(color: Colors.white),
      ));

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        width: SizeConfig().widthSize(context, 85.0),
        height: SizeConfig().heightSize(context, 35.0),
        child: InkWell(
          onTap: () async {
            hasInternet = await InternetConnectionChecker().hasConnection;
            hasInternet
                ? navigateTo(
                    context,
                    MovieDetailes(
                      imdbID: widget.movie.imdbID.toString(),
                      movieName: widget.movie.title,
                    ))
                : ScaffoldMessenger.of(context).showSnackBar(snackBar);
          },
          child: Card(
            margin: const EdgeInsets.symmetric(vertical: 10.0),
            color: Colors.white,
            elevation: 5,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
            child: SizedBox(
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Image.network(
                      widget.movie.poster,
                      height: SizeConfig().heightSize(context, 35.0),
                      fit: BoxFit.cover,
                      errorBuilder: (BuildContext context, Object exception,
                          StackTrace? stackTrace) {
                        return Row(
                          children: [
                            Icon(
                              Icons.error,
                              color: Theme.of(context).colorScheme.primary,
                              size: 30,
                            ),
                            const SizedBox(
                              width: 5.0,
                            ),
                            Text(
                              'image not found',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize:
                                      SizeConfig().widthSize(context, 3.0),
                                  fontFamily: 'Playfair Display'),
                            )
                          ],
                        );
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Expanded(
                    flex: 4,
                    child: Padding(
                      padding: EdgeInsets.all(
                        SizeConfig().widthSize(context, 2.0),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.movie.title,
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    fontFamily: 'Playfair Display',
                                    fontWeight: FontWeight.w700,
                                    fontStyle: FontStyle.italic,
                                    fontSize:
                                        SizeConfig().widthSize(context, 5.0),
                                    color: const Color(0xffEA2828)),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                '${widget.movie.year}  |  ${widget.movie.type.toUpperCase()}',
                                style: TextStyle(
                                    fontFamily: 'Cinzel Decorative',
                                    fontSize:
                                        SizeConfig().widthSize(context, 3.5),
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                            ],
                          ),
                          OutlinedButton(
                              style: ButtonStyle(
                                  fixedSize: MaterialStateProperty.all(Size(
                                    SizeConfig().widthSize(context, 40.0),
                                    SizeConfig().heightSize(context, 8.0),
                                  )),
                                  foregroundColor:
                                      MaterialStateProperty.all(Colors.white),
                                  backgroundColor:
                                      MaterialStateProperty.all(Colors.black),
                                  padding:
                                      MaterialStateProperty.all(EdgeInsets.all(
                                    SizeConfig().widthSize(context, 1.0),
                                  ))),
                              onPressed: () async {
                                var generList = await dbHelper.retrieveGeners();
                                var responce =
                                    await getMovieDetails(widget.movie.imdbID);
                                if (generList.contains(responce.genre)) {
                                  await dbHelper.insertGener(Gener(
                                    title: responce.genre,
                                  ));
                                }
                                addMoviesToWatchList(MoviesWatchList(
                                    imdbID: responce.imdbID,
                                    title: responce.title,
                                    year: responce.year,
                                    imdbRating: responce.imdbRating,
                                    genre: responce.genre,
                                    writer: responce.writer,
                                    director: responce.director,
                                    actors: responce.actors,
                                    plot: responce.plot,
                                    poster: responce.poster,
                                    type: responce.type));
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.add,
                                    size: SizeConfig().widthSize(context, 4.0),
                                  ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    'ADD TO WATCHLIST',
                                    style: TextStyle(
                                      fontFamily: 'Playfair Display',
                                      fontSize:
                                          SizeConfig().widthSize(context, 3.0),
                                    ),
                                  )
                                ],
                              ))
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void navigateTo(context, page) {
    Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) => page,
          transitionDuration: Duration.zero,
        ));
  }
}
