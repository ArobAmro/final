import 'package:flutter/material.dart';
import 'package:movies_app/config/size_config.dart';
import 'package:movies_app/models/gener.dart';
import 'package:movies_app/screens/movie_genre.dart';
import 'package:movies_app/screens/search_about_movie.dart';
import 'package:movies_app/screens/watch_list.dart';
import 'package:movies_app/services/database_handler.dart';
import '../data/static_data.dart';

class NavigationDrawer extends StatefulWidget {
  const NavigationDrawer({Key? key}) : super(key: key);
  @override
  _NavigationDrawerState createState() => _NavigationDrawerState();
}

class _NavigationDrawerState extends State<NavigationDrawer> {
  late DatabaseHelper dbHelper;

  @override
  void initState() {
    super.initState();
    dbHelper = DatabaseHelper();
    dbHelper.initDB().whenComplete(() async {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig().widthSize(context, 65),
      child: Theme(
        data: Theme.of(context).copyWith(
          canvasColor: const Color(0xff5E5C5C),
        ),
        child: Drawer(
          child: ListView(
            padding: EdgeInsets.symmetric(
                horizontal: SizeConfig().widthSize(context, 1.5),
                vertical: SizeConfig().widthSize(context, 3.5)),
            children: [
              ListTile(
                title: Text('Home',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig().widthSize(context, 3.7),
                      fontFamily: 'Playfair Display',
                    )),
                leading: const Icon(Icons.home, color: Color(0xffEA2828)),
                onTap: () {
                  navigateTo(context, const SearchAboutMovie());
                },
              ),
              const Divider(
                color: Color(0xffEA2828),
                thickness: 0.5,
              ),
              ListTile(
                title: Text('Watch List',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig().widthSize(context, 3.7),
                      fontFamily: 'Playfair Display',
                    )),
                leading:
                    const Icon(Icons.watch_later, color: Color(0xffEA2828)),
                onTap: () {
                  navigateTo(context, const WatchList());
                },
              ),
              const Divider(
                color: Color(0xffEA2828),
                thickness: 0.5,
              ),
              ExpansionTile(
                textColor: Colors.white,
                iconColor: Theme.of(context).colorScheme.primary,
                collapsedIconColor: Colors.white,
                children: [GenresSubTitles()],
                childrenPadding:
                    const EdgeInsets.symmetric(vertical: 3.0, horizontal: 65),
                title: Text('Movies Genres',
                    style: TextStyle(
                      fontSize: SizeConfig().widthSize(context, 3.7),
                      fontFamily: 'Playfair Display',
                      color: Colors.white,
                    )),
                leading: const Icon(Icons.category, color: Color(0xffEA2828)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  FutureBuilder<List<Gener>> GenresSubTitles() => FutureBuilder(
        future: dbHelper.retrieveGeners(),
        builder: (BuildContext context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  return InkWell(
                      child: Text(snapshot.data![index].title,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: SizeConfig().widthSize(context, 3.2),
                            fontFamily: 'Playfair Display',
                          )),
                      onTap: () {
                        navigateTo(
                            context,
                            MovieGenre(
                              genre: snapshot.data![index].title,
                            ));
                      });
                });
          }
          ;
          return Text('');
        },
      );

  void navigateTo(context, page) {
    Navigator.of(context).pop();

    Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) => page,
          transitionDuration: Duration.zero,
        ));
  }
}
