import 'package:flutter/material.dart';
import 'package:movies_app/config/size_config.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

class SearchForm extends StatefulWidget {
  final customFunction;
  const SearchForm({Key? key, this.customFunction}) : super(key: key);

  @override
  State<SearchForm> createState() => _SearchFormState();
}

class _SearchFormState extends State<SearchForm> {
  final TextEditingController searchFeildController = TextEditingController();

  final snackBar = const SnackBar(
      backgroundColor: Color(0xffEA2828),
      content: Text(
        'No Internet Connection.',
        style: TextStyle(color: Colors.white),
      ));

  final _formKey = GlobalKey<FormState>();

  final FocusNode _focusNode = FocusNode();

  String? hintText;
  bool hasInternet = true;

  @override
  void dispose() {
    searchFeildController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          SizeConfig().widthSize(context, 3.0),
          SizeConfig().heightSize(context, 2.0),
          SizeConfig().widthSize(context, 2.0),
          0.0),
      child: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            SizedBox(
              width: SizeConfig().widthSize(context, 65.0),
              height: 60,
              child: TextFormField(
                controller: searchFeildController,
                focusNode: _focusNode,
                validator: (value) {
                  if (value != null && value.isEmpty) {
                    return 'Enter Movie name';
                  } else {
                    return null;
                  }
                },
                textAlignVertical: TextAlignVertical.center,
                cursorColor: const Color(0xffEA2828),
                decoration: InputDecoration(
                  label: const Text('Movie Name'),
                  labelStyle: TextStyle(
                    color: Colors.white,
                    fontSize: SizeConfig().widthSize(context, 3.0),
                  ),
                  helperText: ' ',
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1,
                      color: Colors.white,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1,
                      color: Colors.white,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1,
                      color: Color(0xffEA2828),
                    ),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1,
                      color: Color(0xffEA2828),
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                style: TextStyle(
                    color: Colors.white,
                    fontSize: SizeConfig().widthSize(context, 3.5)),
                keyboardType: TextInputType.text,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    hasInternet =
                        await InternetConnectionChecker().hasConnection;
                    if (hasInternet == true) {
                      widget.customFunction(
                          searchFeildController.text, hasInternet);
                    } else {
                      widget.customFunction(
                          searchFeildController.text, hasInternet);
                    }
                  }
                },
                child: Center(
                  child: Icon(
                    Icons.search,
                    color: Colors.white,
                    size: SizeConfig().widthSize(context, 7.0),
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(SizeConfig().widthSize(context, 10.0), 40),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  elevation: 3,
                  padding: const EdgeInsets.all(10.0),
                  primary: const Color(0xffEA2828),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
