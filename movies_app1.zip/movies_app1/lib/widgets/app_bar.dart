import 'package:flutter/material.dart';
import 'package:movies_app/config/size_config.dart';

PreferredSizeWidget CustomAppBar(BuildContext context, String screenTitle) {
  return AppBar(
    centerTitle: true,
    title: Text(
      screenTitle,
      style: TextStyle(
          fontSize: SizeConfig().widthSize(context, 4.5),
          fontFamily: 'Playfair Display'),
    ),
    backgroundColor: const Color(0xffEA2828),
    actions: const [
      Padding(
        padding: EdgeInsets.only(right: 8.0),
        child: Icon(
          Icons.movie,
          size: 20,
        ),
      )
    ],
  );
}
