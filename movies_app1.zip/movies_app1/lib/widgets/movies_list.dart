import 'package:flutter/material.dart';
import 'package:movies_app/widgets/movie_card.dart';

class MoviesList extends StatelessWidget {
  final List moviesList;

  const MoviesList({Key? key, required this.moviesList}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: moviesList.length,
      itemBuilder: (context, index) {
        return MovieCard(
          movie: moviesList[index],
        );
      },
    );
  }
}
