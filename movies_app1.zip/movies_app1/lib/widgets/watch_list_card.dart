import 'package:flutter/material.dart';
import 'package:movies_app/config/size_config.dart';
import 'package:movies_app/models/movie_wach_list.dart';
import 'package:movies_app/screens/movie_details.dart';
// import '../models/movie.dart';

class WatchListCard extends StatelessWidget {
  final MoviesWatchList movie;
  final String? genre;
  final String? navigatedFrom;
  const WatchListCard(
      {Key? key, required this.movie, this.genre, this.navigatedFrom})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        width: SizeConfig().widthSize(context, 85.0),
        height: SizeConfig().heightSize(context, 50.0),
        child: InkWell(
          onTap: () {
            navigateTo(
                context,
                MovieDetailes(
                  imdbID: movie.imdbID.toString(),
                  movieName: movie.title,
                  grnre: genre,
                ));
          },
          child: Card(
            margin: EdgeInsets.symmetric(
                vertical: SizeConfig().heightSize(context, 2.0),
                horizontal: SizeConfig().widthSize(context, 5.0)),
            color: Colors.white,
            elevation: 5,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
            child: Column(children: [
              SizedBox(
                height: SizeConfig().heightSize(context, 25.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5.0),
                  child: Image.network(
                    movie.poster,
                    height: SizeConfig().heightSize(context, 25.0),
                    width: SizeConfig().widthSize(context, 85.0),
                    fit: BoxFit.fitWidth,
                    errorBuilder: (BuildContext context, Object exception,
                        StackTrace? stackTrace) {
                      return Row(
                        children: [
                          Icon(
                            Icons.error,
                            color: Theme.of(context).colorScheme.primary,
                            size: 30,
                          ),
                          const SizedBox(
                            width: 5.0,
                          ),
                          Text(
                            'image not found',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: SizeConfig().widthSize(context, 3.0),
                                fontFamily: 'Playfair Display'),
                          )
                        ],
                      );
                    },
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(movie.title,
                        style: TextStyle(
                            color: Theme.of(context).primaryColor,
                            fontSize: SizeConfig().widthSize(context, 5.0),
                            fontFamily: 'Playfair Display',
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.w700)),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(movie.type,
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: SizeConfig().widthSize(context, 4),
                                fontFamily: 'Cinzel Decorative',
                                fontWeight: FontWeight.w600)),
                        Text(movie.year.toString(),
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: SizeConfig().widthSize(context, 4),
                              fontFamily: 'Cinzel Decorative',
                            )),
                      ],
                    )
                  ],
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  void navigateTo(context, page) {
    Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) => page,
          transitionDuration: Duration.zero,
        ));
  }
}
