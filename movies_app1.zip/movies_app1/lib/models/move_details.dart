class MovieDetails {
  final String imdbID;
  final String title;
  final String year;
  final String imdbRating;
  final String genre;
  final String writer;
  final String director;
  final String actors;
  String plot;
  final String type;
  final String poster;

  MovieDetails(
      {required this.imdbID,
      required this.title,
      required this.year,
      required this.imdbRating,
      required this.genre,
      required this.writer,
      required this.director,
      required this.actors,
      required this.plot,
      required this.type,
      required this.poster});

  factory MovieDetails.fromJson(dynamic json) {
    return MovieDetails(
      imdbID: json['imdbID'],
      title: json['Title'],
      year: json['Year'],
      type: json['Type'],
      poster: json['Poster'],
      plot: json['Plot'],
      imdbRating: json['imdbRating'],
      genre: json['Genre'],
      actors: json['Actors'],
      director: json['Director'],
      writer: json['Writer'],
    );
  }

  Map toJson() => {
        'imdbID': imdbID,
        'Title': title,
        'Year': year,
        'Type': type,
        'Poster': poster,
        'Plot': plot,
        'imdbRating': imdbRating,
        'Genre': genre,
        'Actors': actors,
        'Director': director,
        'Writer': writer,
      };
}
