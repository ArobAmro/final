class Gener {
  String? id;
  final String title;

  Gener({
    this.id,
    required this.title,
  });

  Gener.fromMap(Map<String, dynamic> res)
      : id = res['id'],
        title = res['title'];

  Map<String, Object?> toMap() {
    return {'id': id, 'title': title};
  }
}
