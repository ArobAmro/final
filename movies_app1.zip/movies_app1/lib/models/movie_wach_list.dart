class MoviesWatchList {
  String imdbID;
  String title;
  String year;
  String imdbRating;
  String genre;
  String writer;
  String director;
  String actors;
  String plot;
  String poster;
  String type;

  MoviesWatchList(
      {required this.imdbID,
      required this.title,
      required this.year,
      required this.imdbRating,
      required this.genre,
      required this.writer,
      required this.director,
      required this.actors,
      required this.plot,
      required this.poster,
      required this.type});

  MoviesWatchList.fromMap(Map<String, dynamic> res)
      : imdbID = res["imdbID"],
        title = res["title"],
        year = res["year"],
        imdbRating = res["imdbRating"],
        genre = res["genre"],
        writer = res["writer"],
        director = res["director"],
        actors = res["actors"],
        plot = res["plot"],
        poster = res["poster"],
        type = res["type"];

  Map<String, Object?> toMap() {
    return {
      'imdbID': imdbID,
      'title': title,
      'year': year,
      'imdbRating': imdbRating,
      'genre': genre,
      'writer': writer,
      'director': director,
      'actors': actors,
      'plot': plot,
      'poster': poster,
      'type': type
    };
  }
}
