import 'package:flutter/material.dart';
import 'package:movies_app/config/size_config.dart';
import 'package:movies_app/data/static_data.dart';
import 'package:movies_app/models/gener.dart';
import 'package:movies_app/models/movie.dart';
import 'package:movies_app/models/movie_wach_list.dart';
import 'package:movies_app/services/database_handler.dart';
import 'package:movies_app/widgets/app_bar.dart';
import 'package:movies_app/widgets/navigration_drawer.dart';
import 'package:movies_app/widgets/search_form.dart';
import 'package:movies_app/widgets/watch_list_widget.dart';

class WatchList extends StatefulWidget {
  const WatchList({Key? key}) : super(key: key);

  @override
  _WatchListState createState() => _WatchListState();
}

class _WatchListState extends State<WatchList> {
  late DatabaseHelper dbHelper;
  List<MoviesWatchList> movies = [];
  var generValue;
  @override
  void initState() {
    super.initState();
    dbHelper = DatabaseHelper();
    dbHelper.initDB().whenComplete(() async {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    String searchText = '';
    void getMovies(inputText) {
      setState(() {
        searchText = inputText;
      });
    }

    return Scaffold(
      appBar: CustomAppBar(context, 'Watch List'),
      drawerScrimColor: Colors.grey.withOpacity(0.4),
      drawer: const NavigationDrawer(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SearchForm(customFunction: getMovies),
            const SizedBox(
              height: 2,
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 15),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  FutureBuilder(
                      future: dbHelper.retrieveGeners(),
                      builder: (BuildContext context,
                          AsyncSnapshot<List<Gener>> snapshot) {
                        print(
                            '${snapshot.data} the gener retrive in watch list file');
                        if (snapshot.hasData) {
                          return Container(
                              width: SizeConfig().widthSize(context, 40.0),
                              height: SizeConfig().heightSize(context, 8.0),
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.white, width: 1),
                                  borderRadius: BorderRadius.circular(10)),
                              padding:
                                  const EdgeInsets.only(left: 15, right: 5),
                              child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                value: generValue,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Playfair Display',
                                  fontSize:
                                      SizeConfig().widthSize(context, 3.5),
                                ),
                                hint: Text(
                                  'Genre',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Playfair Display',
                                    fontSize:
                                        SizeConfig().widthSize(context, 3.5),
                                  ),
                                ),
                                elevation: 2,
                                iconEnabledColor:
                                    Theme.of(context).colorScheme.primary,
                                iconSize: SizeConfig().widthSize(context, 8.0),
                                items: snapshot.data!
                                    .map((Gener item) =>
                                        DropdownMenuItem<String>(
                                            value: item.title,
                                            child: Text(item.title)))
                                    .toList(),
                                onChanged: (value) {
                                  setState(() {
                                    generValue = value.toString();
                                  });
                                },
                              )));
                        }
                        return const Text("");
                      }),
                  const SizedBox(
                    width: 2,
                  ),
                  CustomDropDownList(
                    context,
                    'Rating',
                    StaticData.ratings,
                    SizeConfig().widthSize(context, 25.0),
                  ),
                  const SizedBox(
                    width: 2,
                  ),
                  CustomDropDownList(
                    context,
                    'Year',
                    StaticData.years,
                    SizeConfig().widthSize(context, 23.0),
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 10.0,
            ),
            FutureBuilder(
                future: dbHelper.retrieveMoveis(),
                builder: (BuildContext context,
                    AsyncSnapshot<List<MoviesWatchList>> snapshot) {
                  if (snapshot.hasData) {
                    return Center(
                        child:
                            WatchListWidget(watchList: snapshot.data as List));
                  } else if (snapshot.hasError) {
                    print(snapshot.error);
                    return Center(
                        child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 100.0),
                      child: Text(
                        snapshot.error.toString(),
                        style: Theme.of(context).textTheme.headline2,
                      ),
                    ));
                  }
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 100),
                    child: CircularProgressIndicator(
                      color: Color(0xffEA2828),
                    ),
                  );
                }),
          ],
        ),
      ),
    );
  }

  Container CustomDropDownList(
      BuildContext context, String hint, List<String> list, double width) {
    var _dbValue;
    return Container(
        width: width,
        height: SizeConfig().heightSize(context, 8.0),
        decoration: BoxDecoration(
            border: Border.all(color: Colors.white, width: 1),
            borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.only(left: 15, right: 5),
        child: DropdownButtonHideUnderline(
            child: DropdownButton(
          value: _dbValue,
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Playfair Display',
            fontSize: SizeConfig().widthSize(context, 3.5),
          ),
          hint: Text(
            hint,
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Playfair Display',
              fontSize: SizeConfig().widthSize(context, 3.5),
            ),
          ),
          elevation: 2,
          iconEnabledColor: Theme.of(context).colorScheme.primary,
          iconSize: SizeConfig().widthSize(context, 8.0),
          items: list
              .map((String item) =>
                  DropdownMenuItem<String>(value: item, child: Text(item)))
              .toList(),
          onChanged: (value) {
            //here to search about movies in the waatchlist depends on rating ot genre or year
            setState(() {
              _dbValue = value.toString();
              //here to set the movies varible to the result from database
            });
          },
        )));
  }

  void navigateTo(context, page) {
    Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) => page,
          transitionDuration: Duration.zero,
        ));
  }
}
