import 'package:flutter/material.dart';
import 'package:movies_app/widgets/app_bar.dart';
import 'package:movies_app/widgets/movies_list.dart';
import 'package:movies_app/widgets/navigration_drawer.dart';
import 'package:movies_app/widgets/search_form.dart';
import '../services/search_movie_service.dart';

class SearchAboutMovie extends StatefulWidget {
  const SearchAboutMovie({Key? key}) : super(key: key);

  @override
  _SearchAboutMovieState createState() => _SearchAboutMovieState();
}

class _SearchAboutMovieState extends State<SearchAboutMovie> {
  String searchText = '';
  bool isInternetAvailable = true;

  final snackBar = const SnackBar(
      backgroundColor: Color(0xffEA2828),
      content: Text(
        'No Internet Connection.',
        style: TextStyle(color: Colors.white),
      ));

  void getInfo(inputText, hasInternet) {
    print('$isInternetAvailable $searchText');
    setState(() {
      searchText = inputText.toString().trim();
      isInternetAvailable = hasInternet;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        context,
        'Search Movies Screen',
      ),
      drawerScrimColor: Colors.grey.withOpacity(0.4),
      drawer: const NavigationDrawer(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SearchForm(customFunction: getInfo),
            if (searchText.isNotEmpty)
              isInternetAvailable
                  ? FutureBuilder(
                      future: searchMovie(searchText),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return Center(
                              child: MoviesList(
                            moviesList: snapshot.data as List,
                          ));
                        } else if (snapshot.hasError) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 100),
                            child: Text(
                                snapshot.error
                                    .toString()
                                    .replaceRange(0, 11, ''),
                                style: Theme.of(context).textTheme.headline2),
                          );
                        }
                        return const Padding(
                          padding: EdgeInsets.symmetric(vertical: 100),
                          child: CircularProgressIndicator(
                            color: Color(0xffEA2828),
                          ),
                        );
                      })
                  : Padding(
                      padding: const EdgeInsets.symmetric(vertical: 50),
                      child: Text(
                        'No Internet Connection, Please check your network',
                        style: Theme.of(context).textTheme.headline2,
                        textAlign: TextAlign.center,
                      ),
                    )
          ],
        ),
      ),
    );
  }
}
