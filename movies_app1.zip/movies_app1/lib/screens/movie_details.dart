import 'package:flutter/material.dart';
import 'package:movies_app/config/size_config.dart';
import 'package:movies_app/models/move_details.dart';
import 'package:movies_app/services/get_movie_details.dart';
import 'package:movies_app/widgets/app_bar.dart';
import 'package:movies_app/widgets/navigration_drawer.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:internet_connection_checker/internet_connection_checker.dart';

class MovieDetailes extends StatefulWidget {
  final String imdbID;
  final String movieName;
  final String? grnre;
  const MovieDetailes(
      {Key? key, required this.imdbID, required this.movieName, this.grnre})
      : super(key: key);

  @override
  State<MovieDetailes> createState() => _MovieDetailesState();
}

class _MovieDetailesState extends State<MovieDetailes> {
  bool isPlotTapped = false;
  String fullPlot = '';
  bool hasInternet = true;

  final snackBar = const SnackBar(
      backgroundColor: Color(0xffEA2828),
      content: Text(
        'No Internet Connection.',
        style: TextStyle(color: Colors.white),
      ));
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        context,
        widget.movieName,
      ),
      drawerScrimColor: Colors.grey.withOpacity(0.4),
      drawer: const NavigationDrawer(),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              FutureBuilder<MovieDetails>(
                  future: getMovieDetails(widget.imdbID),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          IntrinsicHeight(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    snapshot.data!.title,
                                    style:
                                        Theme.of(context).textTheme.headline1,
                                  ),
                                ),
                                Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        snapshot.data!.imdbRating,
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline2,
                                      ),
                                    ),
                                    const Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 30,
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: Image.network(
                              snapshot.data!.poster,
                              errorBuilder: (BuildContext context,
                                  Object exception, StackTrace? stackTrace) {
                                return Row(
                                  children: [
                                    Icon(
                                      Icons.error,
                                      color:
                                          Theme.of(context).colorScheme.primary,
                                      size: 30,
                                    ),
                                    const SizedBox(
                                      width: 5.0,
                                    ),
                                    const Text(
                                      'image not found',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontFamily: 'Playfair Display'),
                                    )
                                  ],
                                );
                              },
                              height: SizeConfig().heightSize(context, 40.0),
                              width: SizeConfig().widthSize(context, 90.0),
                              fit: BoxFit.fill,
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            '${snapshot.data!.year}  |  ${snapshot.data!.genre}',
                            style: Theme.of(context).textTheme.bodyText2,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          InkWell(
                              child: Text(
                                isPlotTapped ? fullPlot : snapshot.data!.plot,
                                style: Theme.of(context).textTheme.bodyText1,
                              ),
                              onTap: () async {
                                isPlotTapped = true;
                                hasInternet = await InternetConnectionChecker()
                                    .hasConnection;
                                if (hasInternet) {
                                  var response = await http.get(Uri.parse(
                                      "http://www.omdbapi.com/?i=${snapshot.data!.imdbID}&apikey=48b97809&plot=full"));
                                  if (response.statusCode == 200) {
                                    var movieInfo =
                                        convert.jsonDecode(response.body);
                                    if (movieInfo['Response'] == 'True') {
                                      var movieDetails =
                                          MovieDetails.fromJson(movieInfo);
                                      setState(() {
                                        fullPlot = movieDetails.plot;
                                      });
                                      movieDetails;
                                    }
                                  }
                                } else {
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(snackBar);
                                }
                              }),
                          const SizedBox(
                            height: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Actors',
                                style: Theme.of(context).textTheme.headline1,
                              ),
                              Text(
                                snapshot.data!.actors,
                                style: Theme.of(context).textTheme.bodyText1,
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Writer',
                                style: Theme.of(context).textTheme.headline1,
                              ),
                              Text(snapshot.data!.writer,
                                  style: Theme.of(context).textTheme.bodyText1)
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Director',
                                style: Theme.of(context).textTheme.headline1,
                              ),
                              Text(
                                snapshot.data!.director,
                                style: Theme.of(context).textTheme.bodyText1,
                              )
                            ],
                          ),
                        ],
                      );
                    } else if (snapshot.hasError) {
                      return Center(
                        child: Text(
                          '${snapshot.error}',
                          style: Theme.of(context).textTheme.headline2,
                        ),
                      );
                    }
                    return const Center(
                      child: CircularProgressIndicator(
                        color: Color(0xffEA2828),
                      ),
                    );
                  }),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.arrow_back),
        mini: true,
        onPressed: () {
          Navigator.of(context).pop();
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
    );
  }
}
