import 'package:flutter/material.dart';
import 'package:movies_app/models/movie.dart';
import 'package:movies_app/widgets/navigration_drawer.dart';
import 'package:movies_app/widgets/watch_list_widget.dart';

class MovieGenre extends StatefulWidget {
  final String genre;
  const MovieGenre({
    Key? key,
    required this.genre,
  }) : super(key: key);

  @override
  _MovieGenreState createState() => _MovieGenreState();
}

class _MovieGenreState extends State<MovieGenre> {
  List<Movie> movies = [
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
    Movie(
      imdbID: 'tt7286456',
      title: 'Joker',
      type: 'movie',
      poster:
          'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg',
      year: '2019',
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Movies Genres'),
        backgroundColor: const Color(0xffEA2828),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: Icon(Icons.movie),
          )
        ],
      ),
      drawerScrimColor: Colors.grey.withOpacity(0.4),
      drawer: const NavigationDrawer(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(45.0, 20.0, 20.0, 0.0),
              child: Text(
                '${widget.genre} WatchList',
                style: Theme.of(context).textTheme.headline1,
              ),
            ),
            const SizedBox(
              height: 20.0,
            ),
            movies.isNotEmpty
                ? Center(
                    child: WatchListWidget(
                    watchList: movies,
                    genre: widget.genre,
                  ))
                : Padding(
                    padding: const EdgeInsets.symmetric(vertical: 100),
                    child: Text(
                      'Your watchlist doesn\'t have any movie of ${widget.genre} genre yet!',
                      style: Theme.of(context).textTheme.headline2,
                    )),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.arrow_back),
        mini: true,
        onPressed: () {
          Navigator.of(context).pop();
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
    );
  }
}
