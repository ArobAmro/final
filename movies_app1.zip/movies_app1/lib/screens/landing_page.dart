import 'package:flutter/material.dart';
import 'package:movies_app/screens/search_about_movie.dart';

class LandingPage extends StatelessWidget {
  const LandingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    double blockSize = screenWidth / 100;
    double blockSizeVertical = screenHeight / 100;

    return Scaffold(
      body: Stack(children: [
        Container(
          width: screenWidth,
          height: screenHeight,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/images/movie-popcorn.jpg'),
                  fit: BoxFit.cover)),
        ),
        Container(
          margin: EdgeInsets.symmetric(
              horizontal: blockSize * 5.0, vertical: blockSizeVertical * 17.0),
          padding: EdgeInsets.symmetric(horizontal: blockSize * 1.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: blockSize * 60.0,
                height: blockSizeVertical * 15.0,
                child: Text(
                  'Search about your favoruite films, \nAdd it to your watchlist in one place.',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: blockSize * 3.5,
                      fontFamily: 'Cinzel Decorative',
                      fontWeight: FontWeight.w700),
                  textAlign: TextAlign.left,
                ),
              ),
              const SizedBox(height: 2.0),
              ElevatedButton(
                onPressed: () {
                  navigateTo(context, const SearchAboutMovie());
                },
                child: const Text('GET STARTED'),
                style: ElevatedButton.styleFrom(
                    minimumSize:
                        Size(blockSize * 15.0, blockSizeVertical * 8.0),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50)),
                    elevation: 3,
                    onPrimary: Colors.black,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10.0, vertical: 5.0),
                    primary: Colors.white,
                    textStyle: TextStyle(
                        fontSize: blockSize * 3.5,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Cinzel Decorative')),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  void navigateTo(context, page) {
    Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) => page,
          transitionDuration: Duration.zero,
        ));
  }
}
