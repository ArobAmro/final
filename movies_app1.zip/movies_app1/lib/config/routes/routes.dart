class Routes {
  static const String landingPage = '/';
  static const String searchMovie = '/search-movie';
  static const String movieDetails = '/movie-details';
  static const String watchList = '/watch-list';
  static const String movieGenres = '/movie-genres';
  static const String movieGenre = '/movie-genre';
}
