import 'package:flutter/cupertino.dart';

class SizeConfig {
  double widthSize(BuildContext context, double value) {
    return MediaQuery.of(context).size.width / 100 * value;
  }

  double heightSize(BuildContext context, double value) {
    return MediaQuery.of(context).size.height / 100 * value;
  }
}
