import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import '../models/movie.dart';

Future searchMovie(movieTitle) async {
  var response = await http
      .get(Uri.parse("http://www.omdbapi.com/?s=${movieTitle}&apikey=48b97809"));
  if (response.statusCode == 200) {
    Map searchResult = convert.jsonDecode(response.body);
    if (searchResult['Response'] == 'True') {
      var movieList = (searchResult['Search'] as List)
          .map((item) => Movie.fromJson(item))
          .toList();
      return movieList;
    } else {
      throw Exception(searchResult['Error']);
    }
  } else {
    throw Exception('Something went wrong!');
  }
}

