import 'package:movies_app/models/gener.dart';
import 'package:movies_app/models/movie_wach_list.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';

class DatabaseHelper {
  Future<Database> initDB() async {
    String path = await getDatabasesPath();
    return openDatabase(
      join(path, 'movies_demo.db'),
      onCreate: (database, version) async {
        await database.execute(
          '''
        CREATE TABLE watchlist (
              imdbID TEXT PRIMARY KEY, 
              title TEXT ,
              year TEXT , 
              imdbRating TEXT,
              genre TEXT,
              writer TEXT,
              director TEXT,
              actors TEXT,
              plot TEXT,
              poster TEXT,
              type TEXT
            )
        ''',
        );
        await database.execute('''
        CREATE TABLE geners (
              id TEXT PRIMARY KEY,
              genre TEXT
            )
        ''');
      },
      version: 6,
    );
  }

  Future<int?> insertToWatchList(MoviesWatchList moviesWatchList) async {
    final Database db = await initDB();
    final x = await db.insert("watchlist", moviesWatchList.toMap());
    return x;
  }

  Future<int?> insertGener(Gener gener) async {
    final Database db = await initDB();
    final generName = await db.insert('geners', gener.toMap());
    return generName;
  }

  Future<List<MoviesWatchList>> retrieveMoveis() async {
    final Database db = await initDB();
    final List<Map<String, Object?>> queryResult = await db.query('watchlist');
    print('$queryResult');
    return queryResult.map((e) => MoviesWatchList.fromMap(e)).toList();
  }

  Future<List<Gener>> retrieveGeners() async {
    final Database db = await initDB();
    final List<Map<String, Object?>> generQueryResult =
        await db.query('geners');
    print('$generQueryResult this is the gener from database');
    return generQueryResult.map((e) => Gener.fromMap(e)).toList();
  }

  // Future<List<MoviesWatchList>> searchFromWatchList() async {
  //   final Database db = await initDB();
  //   final List<Map<String, Object?>> querySearchResult = await db.rawQuery(
  //       ''' SELECT * FROM watchlist WHERE imdbID = '${MoviesWatchList.imdbID}'; ''');
  //       print('$querySearchResult');
  //   return querySearchResult.map((e) => MoviesWatchList.fromMap(e)).toList();
  // }
}
