import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:movies_app/models/move_details.dart';

Future<MovieDetails> getMovieDetails(id) async {
  var response = await http
      .get(Uri.parse("http://www.omdbapi.com/?i=$id&apikey=48b97809"));
  if (response.statusCode == 200) {
    var movieInfo = convert.jsonDecode(response.body);
    if (movieInfo['Response'] == 'True') {
      var movieDetails = MovieDetails.fromJson(movieInfo);
      return movieDetails;
    } else {
      throw Exception(movieInfo['Error']);
    }
  } else {
    throw Exception('Something went wrong!');
  }
}
