import 'package:flutter/material.dart';
import 'package:movies_app/screens/landing_page.dart';
import 'package:movies_app/screens/movie_details.dart';
import 'package:movies_app/screens/movie_genre.dart';
import 'package:movies_app/screens/search_about_movie.dart';
import 'config/routes/routes.dart';
import 'screens/watch_list.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Movies',
      theme: ThemeData(
        primarySwatch: const MaterialColor(0xffEA2828, <int, Color>{
          50: Color(0xffd32424), //10%
          100: Color(0xffbb2020), //20%
          200: Color(0xffa41c1c), //30%
          300: Color(0xff8c1818), //40%
          400: Color(0xff751414), //50%
          500: Color(0xff5e1010), //60%
          600: Color(0xff460c0c), //70%
          700: Color(0xff2f0808), //80%
          800: Color(0xff170404), //90%
          900: Color(0xff000000),
        }),
        textTheme: const TextTheme(
          headline1: TextStyle(
              color: Color(0xffEA2828),
              fontSize: 20,
              fontFamily: 'Playfair Display',
              fontWeight: FontWeight.w700,
              fontStyle: FontStyle.italic,
              decoration: TextDecoration.underline),
          headline2: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontFamily: 'Playfair Display',
          ),
          bodyText1: TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontFamily: 'Playfair Display',
          ),
          bodyText2: TextStyle(
            color: Color(0xffEA2828),
            fontSize: 15,
            fontFamily: 'Playfair Display',
          ),
        ),
        canvasColor: const Color(0xff1E1C1C),
      ),
      initialRoute: '/',
      routes: {
        Routes.landingPage: (context) => const LandingPage(),
        Routes.searchMovie: (context) => const SearchAboutMovie(),
        Routes.watchList: (context) => const WatchList(),
        Routes.movieGenre: (context) => const MovieGenre(
              genre: '',
            ),
        Routes.movieDetails: (context) => const MovieDetailes(
              imdbID: '',
              movieName: '',
            )
      },
    );
  }
}
